#include <windows.h>
#include <bits/stdc++.h>
#include <conio.h>
#include <fstream>
using namespace std;
int Gs,ans;
string GVS="Officialversion:1.2";
void SetWindow(int w,int h,int x,int y)
{
    HWND hwnd = GetForegroundWindow();
    RECT rect;
    GetWindowRect(hwnd, &rect);
    int newWidth = w;
    int newHeight = h;
    SetWindowPos(hwnd,NULL,rect.left,rect.top,newWidth,newHeight,SWP_NOZORDER|SWP_NOMOVE);
    int newX = x;
    int newY = y;
    SetWindowPos(hwnd,NULL,newX,newY,0,0,SWP_NOSIZE|SWP_NOZORDER);
}
void UpDate()
{
	ifstream udt("UpDateTemp.ini");
	string update;
	udt>>update;
	udt.close();
	if(update!=GVS)
	{
		udt.close();
		cout<<"Please wait for the update..."<<endl;
		Sleep(500);
		system("cls");
		for(int i=1;i<=3;i++)
		{
			cout<<"Please wait for the update..."<<endl;
			cout<<"Update is loading";
			for(int j=1;j<=3;j++)
			{
				cout<<".";
				Sleep(100);
			}
			system("cls");
		}
		for(int i=1;i<=99;i++)
		{
			system("cls");
			cout<<"Updating..."<<endl;
			if(i%3==0) continue;
			cout<<"Update is finish %"<<i;
		}
		Sleep(200);
		ofstream udt("UpDateTemp.ini");
		udt<<GVS;
		udt.close();
		system("cls");
		cout<<"Updating..."<<endl<<"Update is finish %100"<<endl;
		cout<<"Update is complete"<<endl;
		cout<<"Please press any key to continue";
		getch();
	}
	system("cls");
}
string addpd(string upd) 
{
	for(int i=0;i<upd.size();i++)
	{
		upd[i]=upd[i]+'x'+'t'+'h';
		if(i==1) upd[i]+=710;
		if(i==4) upd[i]+=16;
		if(i==16) upd[i]+=2024;
	}
	return upd+upd+upd;
}
void User()
{
	ifstream ut("UserImformation.ini");
	if(ut.is_open())
	{
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=20)
			{
				for(int i=10;i>0;i--)
				{
					cout<<"Your conputer will shutdown in 10 seconds"<<endl;
					cout<<i;
					Sleep(1000);
					system("cls");
				}
				system("shutdown /s /t 0");
			}
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				system("cls");
			}
			cout<<"Please input "<<tun<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==tup)
			{
				ifstream gi("GameImformation.ini");
				if(gi.is_open()) gi>>Gs;
				else Gs=0;
				system("cls");
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				system("cls");
				break;
			}
			else
			{
				system("cls");
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			system("cls");
		}
	}
	else
	{
		ut.close();
		cout<<"This computer does not have user information, please register an account"<<endl;
		string username,upasswd;
		while(1)
		{
			cout<<"Please input the username:";
			cin>>username;
			cout<<endl<<"Please input the password:";
			cin>>upasswd;
			if(upasswd.size()<6)
			{
				cout<<"Please input a longer password"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				system("cls");
				continue;
			}
			if(upasswd==username)
			{
				cout<<"The password can't include the username"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				system("cls");
				continue;
			}
			break;
		}
		ofstream oui("UserImformation.ini");
		oui<<username<<endl<<addpd(upasswd);
		oui.close();
		ofstream outi("GameImformation.ini");
		outi<<0;
		outi.close();
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		cout<<"User data configuration completed, please log in."<<endl;
		cout<<"Please press any key to continue";
		getch();
		oui.close();
		system("cls");
		ifstream ut("UserImformation.ini");
		string un,up;
		ut>>un>>up;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				system("cls");
			}
			cout<<"Please input "<<un<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==up)
			{
				ifstream gi("GameImformation.ini");
				if(gi.is_open()) gi>>Gs;
				else Gs=0;
				system("cls");
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				system("cls");
				break;
			}
			else
			{
				system("cls");
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			system("cls");
		}
	}
}
void rock()
{
	system("cls");
	while(1)
	{
		cout<<"Please enter gesture number:"<<endl<<"1.Stone 2.Scissors 3.Cloth"<<endl<<"Enter 0 to exit";
		int rock_num;
		cout<<endl;
		cin>>rock_num;
		if(rock_num==0) break;
		else if(rock_num==1) cout<<"The robot wins,the robot inputs CLOTH"<<endl;
		else if(rock_num==2) cout<<"The robot wins,the robot inputs STONE"<<endl;
		else if(rock_num==3) cout<<"The robot wins,the robot inputs SCISSOR"<<endl;
		else cout<<"Input error,please re-enter..."<<endl;
		Gs++;
		cout<<endl;
	}
	system("cls");
}
void help()
{
	system("cls");
	cout<<"Do you want to download the file:'How To Use This Game.txt'?"<<endl;
	cout<<"1.Yes  2.No"<<endl;
	int helpans;
	cin>>helpans;
	if(helpans==1)
	{
		cout<<"The file is downloading..."<<endl;
		ofstream heof("How To Use This Game.txt");
		heof<<"I don't know..."<<endl;
		if(heof.is_open())
		{
			cout<<"Download Accept"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		heof.close();
	}
	else if(helpans==2)
	{
		cout<<"OK,download is end"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
	}
	else
	{
		cout<<"Input error."<<endl;
		Sleep(1000);
		system("cls");
	}
	system("cls"); 
}
void uptempnew()
{
	system("cls");
	Gs+=2;
	cout<<"Please provide feedback to your email if there are any errors:ASheepBoy_Bed@163.com"<<endl;
	cout<<"The new of the "<<GVS<<':'<<endl;
	cout<<"  -Add Mouse linker."<<endl;
	cout<<"  -Fixed known errors."<<endl;
	cout<<"  -Optimized performance."<<endl;
	cout<<"  -Add error feedback."<<endl;
	cout<<"  -Optimized the interface."<<endl;
	cout<<"  -Add the testing website."<<endl;
	cout<<"If you want to know more about this Game,you can input 1 to download the 'UpDate.txt''"<<endl;
	cout<<"Input 0 to exit"<<endl;
	string uta;
	cin>>uta;
	if(uta=="1")
	{
		cout<<"'UpDate.txt' is download...";
		ofstream utn("UpDate.txt");
		utn<<"NEWS(Officialversion:1.1)"<<endl<<"------------------"<<endl<<"  -Add News."<<endl<<"  -Add the 'NEW' flags."<<endl<<"  -Reset the window."<<endl<<"  -Optimized performance."<<endl<<"  -If you input 20 times wrong password,your PC will shutdown."<<endl<<endl;
		if(utn.is_open())
		{
			cout<<"Download Accept"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		utn.close();
	}
	else
	{
		system("cls");
	}
	system("cls");
}
void find8()
{
	system("cls");
	cout<<"Please find the '8' in the '0' and enter the position of 8"<<endl;
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
	for(int i=3;i>=1;i--)
	{
		cout<<i;
		Sleep(500);
		system("cls");
	}
	for(int i=1;i<=100;i++)
	{
		if(i==64)
		{
			cout<<8;
			continue;
		}
		cout<<0;
	}
	cout<<endl<<"Please input your answer:";
	int fans;
	cin>>fans;
	if(fans==64)
	{
		cout<<"Congratulations,you answered is correctly.";
		cout<<"The game score will be increased by 10"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=10;
		system("cls");
	}
	else
	{
		cout<<"Wrong answer..."<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
		system("cls");
	}
}
void create()
{
	system("cls");
	cout<<"Are you feeling frustrated about not being able to create files?";
	cout<<" Use this tool to make sure you don't feel frustrated"<<endl;
	string cfname,cfcon;
	cout<<"Please enter the file name:";
	cin>>cfname;
	cout<<endl<<"Please enter the file content:";
	cin>>cfcon;
	cfname+=".txt";
	ofstream cfile(cfname.c_str());
	cfile<<cfcon;
	if(cfile.is_open())
	{
		cout<<endl<<"Create success"<<endl;
		Gs+=5;
	}
	else
	{
		cout<<endl<<"Create fail"<<endl;
		Gs++;
	}
	cfile.close();
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
}
void calculator()
{
	system("cls");
	cout<<"This is a calculator that can help you to count"<<endl;
	cout<<"Only supports addition (+), subtraction (-), multiplication (*), division (/)"<<endl;
	long long n1,n2;
	char fh;
	cin>>n1>>fh>>n2;
	if(fh=='+') cout<<n1<<'+'<<n2<<'='<<n1+n2<<endl;
	else if(fh=='-') cout<<n1<<'-'<<n2<<'='<<n1-n2<<endl;
	else if(fh=='*') cout<<n1<<'*'<<n2<<'='<<n1*n2<<endl;
	else if(fh=='/')cout<<n1<<'/'<<n2<<'='<<n1/n2<<"......"<<n1%n2<<endl;
	else cout<<"Input error..."<<endl;
	Gs+=2;
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
}
void Mousefp()
{
	system("cls");
    cout<<"Please enter the click interval duration(in ms)(Fastest 1 millisecond):"<<endl;
    int midt;
    cin>>midt;
    system("cls");
	cout<<"Press F2 to execute,press F4 to stop,press ESC to exit"<<endl;
	cout<<"Speed:"<<midt<<"ms/time"<<endl;
	cout<<"(CPS testing website:'5vmc.com/cps')"<<endl;
	while(1)
	{
		if(GetAsyncKeyState(VK_F2))
		{
			Gs+=2;
			while(1)
			{
				mouse_event(MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_LEFTUP,0,0,0,0);
				if(GetAsyncKeyState(VK_F4))
				{
					break;
				}
				Sleep(midt);
			}
		}
		if(GetAsyncKeyState(VK_ESCAPE))
		{
			break;
		}
	}
	system("cls");
}
int main()
{
	SetWindow(900,450,200,200);
	UpDate();
	User();
	system("cls");
	while(1)
	{
		cout<<"NOTE:Please enter 0 to exit the game,";
		cout<<"otherwise the game score will not be saved"<<endl<<endl;
		cout<<"1.Help"<<endl;
		cout<<"2.What's New?"<<endl;
		cout<<"3.Stone Scissors And Cloth"<<endl;
		cout<<"4.Hide And Seek"<<endl;
		cout<<"5.Create Files"<<endl;
		cout<<"6.Calculator"<<endl;
		cout<<"7.Mouse linker (NEW!)"<<endl;
		
		cout<<endl;
		cout<<"Your Game score is "<<Gs<<endl;
		cout<<"Please input the Game number(input 0 to exit):";
		cin>>ans;
		if(ans==0)
		{
			ofstream ogi("GameImformation.ini");
			ogi<<Gs;
			return 0;
		}
		else if(ans==1) help();
		else if(ans==2) uptempnew();
		else if(ans==3) rock();
		else if(ans==4) find8();
		else if(ans==5) create();
		else if(ans==6) calculator(); 
		else if(ans==7) Mousefp();
		
		else cout<<"Input error,please input again"<<endl;
	}
}














