#include <windows.h>
#include <bits/stdc++.h>
#include <conio.h>
#include <fstream>
using namespace std;
long long Gs;
string Gsp;
string GVS="Officialversion:1.7",ans;
void cls()
{
	string cls="cls";
	system(cls.c_str());
}
long long Gsap(string x)
{
	return x.size();
}
string Gsaj(long long x)
{
	string ans="";
	for(int i=1;i<=x;i++)
	{
		ans+='.';
	}
	return ans;
}
void SetWindow()
{
	int w,h,x,y;
	ifstream sw("Temp\\GameWindowImformation.bat");
	if(!sw.is_open())
	{
		w=900;h=450;x=200;y=200;
	}
	else sw>>w>>h>>x>>y;
    HWND hwnd = GetForegroundWindow();
    RECT rect;
    GetWindowRect(hwnd, &rect);
    int newWidth = w;
    int newHeight = h;
    SetWindowPos(hwnd,NULL,rect.left,rect.top,newWidth,newHeight,SWP_NOZORDER|SWP_NOMOVE);
    int newX = x;
    int newY = y;
    SetWindowPos(hwnd,NULL,newX,newY,0,0,SWP_NOSIZE|SWP_NOZORDER);
}
void UpDate()
{
	ifstream udt("Temp\\UpDateTemp.ini");
	string update;
	udt>>update;
	udt.close();
	system("mkdir Temp");
	if(update!=GVS)
	{
		udt.close();
		cout<<"Please wait for the update..."<<endl;
		Sleep(500);
		cls();
		for(int i=1;i<=3;i++)
		{
			cout<<"Please wait for the update..."<<endl;
			cout<<"Update is loading";
			for(int j=1;j<=3;j++)
			{
				cout<<".";
				Sleep(100);
			}
			cls();
		}
		for(int i=1;i<=99;i++)
		{
			cls();
			cout<<"Updating..."<<endl;
			if(i%3==0) continue;
			cout<<"Update is finish %"<<i;
		}
		Sleep(200);
		ofstream udt("Temp\\UpDateTemp.ini");
		udt<<GVS;
		udt.close();
		cls();
		cout<<"Updating..."<<endl<<"Update is finish %100"<<endl;
		cout<<"Update is complete"<<endl;
		cout<<"Please press any key to continue";
		getch();
	}
	cls();
}
string addpd(string upd)
{
	for(int i=0;i<upd.size();i++)
	{
		upd[i]=upd[i]+'x'+'t'+'h';
		if(i==1) upd[i]+=710;
		if(i==4) upd[i]+=16;
		if(i==16) upd[i]+=2024;
	}
	return upd+upd+upd;
}
void User()
{
	ifstream ut("Temp\\UserImformation.ini");
	if(ut.is_open())
	{
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=20)
			{
				for(int i=10;i>0;i--)
				{
					cout<<"Your computer will shutdown in 10 seconds"<<endl;
					cout<<i;
					Sleep(10000);
					cls();
				}
				system("shutdown /s /t 0");
			}
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				cls();
			}
			cout<<"Please input "<<tun<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==tup)
			{
				ifstream gi("Temp\\GameImformation.ini");
				if(gi.is_open()) gi>>Gsp;
				else Gs=0;
				cls();
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				cls();
				break;
			}
			else
			{
				cls();
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			cls();
		}
	}
	else
	{
		ut.close();
		cout<<"This computer does not have user information, please register an account"<<endl;
		string username,upasswd;
		while(1)
		{
			cout<<"Please input the username:";
			cin>>username;
			cout<<endl<<"Please input the password:";
			cin>>upasswd;
			if(upasswd.size()<6)
			{
				cout<<"Please input a longer password"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				cls();
				continue;
			}
			if(upasswd==username)
			{
				cout<<"The password can't include the username"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				cls();
				continue;
			}
			if(upasswd=="111111" or upasswd=="123456" or upasswd=="000000")
			{
				cout<<"The password is not safty,please change another"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				cls();
				continue;
			}
			break;
		}
		ofstream oui("Temp\\UserImformation.ini");
		oui<<username<<endl<<addpd(upasswd);
		oui.close();
		ofstream outi("Temp\\GameImformation.ini");
		outi<<0;
		outi.close();
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		cout<<"User data configuration completed, please log in."<<endl;
		cout<<"Please press any key to continue";
		getch();
		oui.close();
		cls();
		ifstream ut("Temp\\UserImformation.ini");
		string un,up;
		ut>>un>>up;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				cls();
			}
			cout<<"Please input "<<un<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==up)
			{
				ifstream gi("Temp\\GameImformation.ini");
				if(gi.is_open()) gi>>Gsp;
				else Gs=0;
				cls();
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				cls();
				break;
			}
			else
			{
				cls();
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			cls();
		}
	}
}
int Rand(int ranse)
{
	SYSTEMTIME sys;
	GetLocalTime(&sys);
	int Rlocal=sys.wMilliseconds/ranse;
	return Rlocal;
}
void rock()
{
	cls();
	while(1)
	{
		cout<<"Please enter gesture number:"<<endl<<"1.Stone 2.Scissors 3.Cloth"<<endl<<"Enter 0 to exit";
		int rock_num,rock_rand=Rand(100);
		if(rock_rand<=2) rock_rand=1;
		else if(rock_rand<=6) rock_rand=2;
		else rock_rand=3;
		cout<<endl;
		cin>>rock_num;
		if(rock_num==0) break;
		else if(rock_num==1)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input STONE!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input SCISSORS!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs CLOTH!"<<endl;Gs+=1;}
		}
		else if(rock_num==2)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input SCISSORS!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input CLOTH!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs STONE!"<<endl;Gs+=1;}
		}
		else if(rock_num==3)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input CLOTH!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input STONE!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs SCISSORS!"<<endl;Gs+=1;}
		}
		else cout<<"Input error,please re-enter..."<<endl;
		cout<<endl;
	}
	cls();
}
void help()
{
	cls();
	cout<<"Do you want to download the file:'How To Use This Game.txt'"<<endl;
	cout<<"1.Yes  2.No"<<endl;
	int helpans;
	cin>>helpans;
	if(helpans==1)
	{
		cout<<"The file is downloading..."<<endl;
		ofstream heof("C:\\Users\\Administrator\\Desktop\\How To Use This Game.txt");
		heof<<"I don't know..."<<endl;
		if(heof.is_open())
		{
			cout<<"Download Accept,please read this file on your desktop"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		heof.close();
	}
	else if(helpans==2)
	{
		cout<<"OK,download is end"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
	}
	else
	{
		cout<<"Input error."<<endl;
		Sleep(1000);
		cls();
	}
	cls();
}
void Uptempnew()
{
	cls();
	Gs+=2;
	cout<<"Please provide feedback to your email if there are any errors:ASheepBoy@outlook.com"<<endl;
	cout<<"The new of the "<<GVS<<':'<<" (2024.3.17)"<<endl;

	cout<<"  -Fix the password texting."<<endl;
	cout<<"  -Fix the Game score rule."<<endl;
	cout<<"  -Add Reactivity Test."<<endl;
	cout<<"  -Add folder at the main page."<<endl;
	cout<<"  -Fix the shutdown time."<<endl;
	cout<<"  -Optimized performance."<<endl;
	cout<<"  -Add password at Game score."<<endl;

	//Add here��
	//if finish,add . at last
	cout<<"If you want to know more about this Game,you can input 1 to download the 'UpDate.txt''"<<endl;
	cout<<"Input 0 to exit"<<endl;
	string uta;
	cin>>uta;
	if(uta=="1")
	{
		cout<<"'UpDate.txt' is download...";
		ofstream utn("C:\\Users\\Administrator\\Desktop\\UpDate.txt");
		utn<<"NEWS(Officialversion:1.1)2024.1.11"<<endl<<"--------------------"<<endl<<"  -Add News."<<endl<<"  -Add the 'NEW' flags."<<endl<<"  -Reset the window."<<endl<<"  -Optimized performance."<<endl<<"  -If you input 20 times wrong password,your PC will shutdown."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.2)2024.1.30"<<endl<<"--------------------"<<endl<<"  -Add Mouse linker."<<endl<<"  -Fixed known errors."<<endl<<"  -Optimized performance."<<endl<<"  -Add error feedback."<<endl<<"  -Optimized the interface."<<endl<<"  -Add the testing website."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.3)2024.2.2"<<endl<<"--------------------"<<endl<<"  -Optimized program code."<<endl<<"  -Revised bonus point rules."<<endl<<"  -Optimized performance."<<endl<<"  -Fixed known errors."<<endl<<"  -Add the date in update imformation."<<endl<<"  -Add the system time."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.4)2024.2.16"<<endl<<"--------------------"<<endl<<"  -Optimized performance."<<endl<<"  -Fixed known errors."<<endl<<"  -Add random in Stone Scissors And Cloth."<<endl<<"  -Add Guess Number."<<endl<<"  -Add random in Hide And Seek."<<endl<<"  -Add protective measures."<<endl<<"  -Add pleasantly surprised."<<endl<<"  -Changed the location of the file"<<endl<<endl;
		utn<<"NEWS(Officialversion:1.5)2024.2.20"<<endl<<"--------------------"<<endl<<"  -Fixed the Surprise."<<endl<<"  -Fixed the code."<<endl<<"  -Add settings."<<endl<<"  -Optimized performance."<<endl<<"  -Add setting colors."<<endl<<"  -Add Remember colors."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.6)2024.2.30"<<endl<<"--------------------"<<endl<<"  -Fix settings."<<endl<<"  -Add window setting."<<endl<<"  -Add operator settings."<<endl<<"  -Optimized performance."<<endl<<"  -Fixed known errors."<<endl<<"  -Add password safty application."<<endl<<"  -Fixed the operator settings."<<endl<<"  -Add more color at settings."<<endl<<endl;
		if(utn.is_open())
		{
			cout<<"Download Accept,please read this file on your desktop"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		utn.close();
	}
	else
	{
		cls();
	}
	cls();
}
void find8()
{
	cls();
	cout<<"Please find the '8' in the '0' and enter the position of 8"<<endl;
	cout<<"Please press any key to continue"<<endl;
	getch();
	cls();
	int randans=Rand(10);
	if(randans<=0||randans>=100) randans=64;
	for(int i=1;i<=100;i++)
	{
		if(i==randans)
		{
			cout<<8;
			continue;
		}
		cout<<0;
	}
	cout<<endl<<"Please input your answer:";
	int fans;
	cin>>fans;
	if(fans==randans)
	{
		cout<<"Congratulations,you answered is correctly.";
		cout<<"The game score will be increased by 10"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=10;
		cls();
	}
	else
	{
		cout<<"Wrong answer..."<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
		cls();
	}
}
void create()
{
	cls();
	cout<<"Are you feeling frustrated about not being able to create files";
	cout<<" Use this tool to make sure you don't feel frustrated"<<endl;
	string cfname,cfcon;
	cout<<"Please enter the file name:";
	cin>>cfname;
	cout<<endl<<"Please enter the file content:";
	cin>>cfcon;
	cfname="C:\\Users\\Administrator\\Desktop\\"+cfcon+".txt";
	ofstream cfile(cfname.c_str());
	cfile<<cfcon;
	if(cfile.is_open())
	{
		cout<<endl<<"Create success,please read this file on your desktop"<<endl;
		Gs+=5;
	}
	else
	{
		cout<<endl<<"Create fail"<<endl;
		Gs++;
	}
	cfile.close();
	cout<<"Please press any key to continue"<<endl;
	getch();
	cls();
}
void calculator()
{
	cls();
	cout<<"This is a calculator that can help you to count"<<endl;
	cout<<"Only supports addition (+), subtraction (-), multiplication (*), division (/)"<<endl;
	long long n1,n2;
	char fh;
	cin>>n1>>fh>>n2;
	if(fh=='+') cout<<n1<<'+'<<n2<<'='<<n1+n2<<endl;
	else if(fh=='-') cout<<n1<<'-'<<n2<<'='<<n1-n2<<endl;
	else if(fh=='*') cout<<n1<<'*'<<n2<<'='<<n1*n2<<endl;
	else if(fh=='/')cout<<n1<<'/'<<n2<<'='<<n1/n2<<"......"<<n1%n2<<endl;
	else cout<<"Input error..."<<endl;
	Gs+=2;
	cout<<"Please press any key to continue"<<endl;
	getch();
	cls();
}
void Surprise()
{
	for(int i=1;i<=10;i++)
	{
		system("color a0");
		system("color b0");
		system("color c0");
		system("color d0");
		system("color e0");
		system("color f0");
		system("color a");
	}
	cls();
	Gs+=1;
}
void Mousefp()
{
	cls();
    cout<<"Please enter the click interval duration(in ms)(Fastest 1 millisecond):"<<endl;
    int midt;
    cin>>midt;
    cls();
	cout<<"Press F2 to execute,press F4 to stop,press ESC to exit"<<endl;
	cout<<"Speed:"<<midt<<"ms/x"<<endl;
	cout<<"(CPS testing website:'5vmc.com/cps')"<<endl;
	Gs+=10;
	while(1)
	{
		if(GetAsyncKeyState(VK_F2))
		{
			while(1)
			{
				mouse_event(MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_LEFTUP,0,0,0,0);
				if(GetAsyncKeyState(VK_F4))
				{
					break;
				}
				Sleep(midt);
			}
		}
		if(GetAsyncKeyState(VK_ESCAPE))
		{
			break;
		}
	}
	cls();
}
void Guess()
{
	cls();
	int gans;
	int guenum=Rand(10);
	if(guenum<=0||guenum>=100) guenum=64;
	cout<<"The robot is thinking a number..."<<endl;
	cout<<"The robot is ready,please input a number first(0~100)"<<endl;
	while(1)
	{
		cout<<"Input -1 to exit"<<endl;
		cin>>gans;
		if(gans==-1) break;
		else if(gans==guenum)
		{
			cout<<"Congratulations,you answered is correctly.";
			cout<<"The game score will be increased by 10"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
			cls();
			break;
		}
		else if(gans>guenum) cout<<"Your number is too big!"<<endl;
		else if(gans<guenum) cout<<"Your number is too small!"<<endl;
		else
		{
			cout<<"Wrong answer..."<<endl<<endl;
			Gs++;
		}
	}
	cls();
}
void SetColor()
{
	ifstream csc("Temp\\GameColor.bat");
	if(!csc.is_open()) return;
	string csa;
	csc>>csa;
	csa="color "+csa;
	system(csa.c_str());
}
void Settings()
{
	cls();
	cout<<"1.Set color"<<endl;
	cout<<"2.Set window"<<endl;
	cout<<"3.Operator settings(Non professionals are not allowed to use)"<<endl;
	char setans;
	cin>>setans;
	if(setans=='1')
	{
		cls();
		cout<<"please input the foreground color:"<<endl;
		cout<<"0=Black"<<endl<<"1=Blue"<<endl<<"2=Green"<<endl<<"3=light green"<<endl<<"4=Red"<<endl<<"5=Purple"<<endl<<"6=Yellow"<<endl<<"7=White"<<endl<<"8=Gray"<<endl<<"9=light blue"<<endl<<"A=light green"<<endl<<"B=light green"<<endl<<"C=light red"<<endl<<"D=light purple"<<endl<<"E=light yellow"<<endl<<"F=Bright white"<<endl;
		string ans;
		cin>>ans;
		if(ans=="1"||ans=="2"||ans=="3"||ans=="4"||ans=="5"||ans=="6"||ans=="7"||ans=="8"||ans=="9"||ans=="a"||ans=="b"||ans=="c"||ans=="d"||ans=="e"||ans=="f"||ans=="A"||ans=="B"||ans=="C"||ans=="D"||ans=="E"||ans=="F")
		{
			ofstream sc("Temp\\GameColor.bat");
			sc<<ans<<endl;
			ans="color "+ans;
			system(ans.c_str());
			cls();
		}
		else
		{
			cls();
			return;
		}
	}
	else if(setans=='2')
	{
		cls();
		cout<<"Please input the Window's weight(in pixel):";
		int aw,ah;
		cin>>aw;
		cout<<endl<<"Please input the Window's hight(in pixel):";
		cin>>ah;
		ofstream sws("Temp\\GameWindowImformation.bat");
		sws<<aw<<endl<<ah<<endl<<200<<endl<<200;
		sws.close();
		SetWindow();
	}
	else if(setans=='3')
	{
		system("color f");
		for(int i=1;i<=20;i++)
		{
			if(i%2==0) system("dir/s");
			else system("tree");
			if(i==3||i==5||i==8||i==13||i==16)
			{
				Sleep(100);
			}
		}
		SetColor();
		cls();
		while(1)
		{
			string kfs;
			getline(cin,kfs);
			if(kfs=="-1")
			{
				break;
			}
			else
			{
				system(kfs.c_str());
			}
		}
	}
	cls();
	Gs+=2;
}
void Passwdt()
{
	cls();
	string pst,psj="";
	int ptimes=0;
	cout<<"Please input your password:";
	getline(cin,pst);
	getline(cin,pst);
	cls();
	cout<<"Please wait..."<<endl;
	cout<<"The command is getting your password..."<<endl;
	for(int i=0;i<pst.size();i++)
	{
		int cnt=0;
		bool flag=false;
		for(int j=0;j<128;j++)
		{
			if((char)j==pst[i])
			{
				psj+=(char)j;
				flag=true;
				ptimes++;
				Sleep(2);
			}
		}
		if(flag=false)
		{
			psj[i]+=pst[i];
		}
	}
	Sleep(1000);
	ptimes+=psj.size()+Rand(100);
	if(psj!=pst) return;
	cout<<"Your password is: "<<psj<<endl<<"Used "<<ptimes*10<<" ms"<<endl<<endl;
	cout<<(ptimes>20 ? "Your password is strong." : "Your password is too easy.")<<endl;
	cout<<"Please press any key to continue."<<endl;
	getch();
	system("cls");
	Gs+=(psj.size()>=10 ? 4 : 2);
}
void fylcs()
{
	cls();
	cout<<"This is a Reactivity Test"<<endl;
	cout<<"Please press the SPACE when the color is change"<<endl;
	cout<<"Please press any key to continue."<<endl;
	getch();
	for(int i=5;i>=0;i--)
	{
		cout<<i<<endl;
		Sleep(300);
	}
	int fb=0;
	system("color 7c");
	cls();
	for(int i=1;i<=10;i++)
	{
	    cout<<"Press SPACE!"<<endl;
		if(GetAsyncKeyState(VK_SPACE))
		{
			fb++;
			cout<<"Key Down"<<endl;
		}
		Sleep(10);
	}
	SetColor();
	if(fb>1)
	{
	    cout<<"Congratulations!"<<endl<<"Your reactivite is very fast!"<<endl<<"Your Game score will add 10."<<endl;
		Gs+=8;
	}
	else
		cout<<"Your reactivite is slow , and you miss the time!"<<endl;
	Sleep(4000);
	cls();
	Gs+=2;
}
void Time()
{
	Gs+=2;
	cls();
	ifstream tt("Temp\\TimeImformation.ini");
	if(!tt.is_open())
	{
		tt.close();
		cout<<"Please input the go to work time:(in Hours)(24hours a day)";
		int t_on_h,t_on_m,t_do_h,t_do_m;
		cin>>t_on_h;
		cout<<"Please input the go to work time:(in Minutes)(24hours a day)";
		cin>>t_on_m;
		cout<<endl<<"Please input the after work time:(in Hours)(24hours a day)";
		cin>>t_do_h;
		cout<<"Please input the after work time:(in Minutes)(24hours a day)";
		cin>>t_do_m;
		cout<<endl<<"Please wait..."<<endl;
		ofstream ott("Temp\\TimeImformation.ini");
		ott<<t_on_h<<' '<<t_on_m<<endl<<t_do_h<<' '<<t_do_m;
		cout<<"Complete!"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
	}
	ifstream ttf("Temp\\TimeImformation.ini");
	if(tt.is_open())
	{
		SYSTEMTIME s;
		GetLocalTime(&s);
		int toh,tom,tdh,tdm;
		ttf>>toh>>tom>>tdh>>tdm;
		if((tdh<=s.wHour&&tdm<=s.wMinute)||(toh>=s.wHour&&tom>s.wMinute))
		{
			for(;;)
			{
				cout<<"You are resting..."<<endl;
				cout<<"Please press ESC to exit"<<endl;
				if(GetAsyncKeyState(VK_ESCAPE))
				{
					return;
				}
				Sleep(10);
				cls();
			}
		}
		int se=(60-s.wSecond);
		for(int h=tdh-s.wHour-1;h>=0;h--)
		{
			for(int m=(tdm>s.wMinute ? tdm-s.wMinute : 60+tdm-s.wMinute)-1;m>=0;m--)
			{
				for(;se>=0;se--)
				{
					cout<<"(Please press ESC to exit)"<<endl;
					cout<<"After work time left "<<h<<':'<<m<<':'<<se;
					Sleep(1000);
					cls();
					if(GetAsyncKeyState(VK_ESCAPE))
					{
						return;
					}
				}
				se=59;
			}
		}
		if((tdh>=s.wHour&&tdm>=s.wMinute)||(toh<=s.wHour&&tom<s.wMinute))
		{
			for(;;)
			{
				cout<<"You are resting..."<<endl;
				cout<<"Please press ESC to exit"<<endl;
				if(GetAsyncKeyState(VK_ESCAPE))
				{
					return;
				}
				Sleep(50);
				cls();
//				int se=(60-s.wSecond);
//				SYSTEMTIME sg;
//				GetLocalTime(&sg);
//				if(!((tdh>=sg.wHour&&tdm>=sg.wMinute)||(toh<=sg.wHour&&tom<sg.wMinute)))
//				{
//				 	for(int h=tdh-sg.wHour-1;h>=0;h--)
//					{
//						for(int m=(tdm>sg.wMinute ? tdm-sg.wMinute : 60+tdm-sg.wMinute)-1;m>=0;m--)
//						{
//							for(;se>=0;se--)
//							{
//								cout<<"(Please press ESC to exit)"<<endl;
//								cout<<"After work time left "<<h<<':'<<m<<':'<<se;
//								Sleep(1000);
//								cls();
//								if(GetAsyncKeyState(VK_ESCAPE))
//								{
//									return;
//								}
//							}
//							se=59;
//						}
//					}
//				}
			}
		}
	}
}
#define KEY_DOWN(VK_NONAME)((GetAsyncKeyState(VK_NONAME)& 0x8000)? 1:0)
POINT p;
HWND h=GetForegroundWindow();
int main()
{
	SetColor();
	SetWindow();
	UpDate();
    //User();
    Gs=0;
    Gs=Gsap(Gsp);
	while(1)
	{
		cls();
		SYSTEMTIME sys;
		GetLocalTime(&sys);
		printf("Now system time:%4d/%02d/%02d %02d:%02d\n",sys.wYear,sys.wMonth,sys.wDay,sys.wHour,sys.wMinute);
		cout<<"NOTE:Please input 0 to exit the game,";
		cout<<"otherwise the game score will not be saved"<<endl<<endl;
		cout<<"1.About"<<endl;
		cout<<"2.Little Game"<<endl;
		cout<<"3.Practical tools"<<endl;
		cout<<"4.Texting tools"<<endl;

		//add here��
		cout<<endl;
		cout<<"Your Game score is "<<Gs<<endl;
		cout<<"Please input the folder number:";
		cin>>ans;
		if(ans=="0")
		{
			ofstream ogi("Temp\\GameImformation.ini");
			ogi<<Gsaj(Gs);
			return 0;
		}
		else if(ans=="1")
		{
			cls();
			cout<<"About:"<<endl;
			cout<<"  1.Help"<<endl;
			cout<<"  2.What's New"<<endl;
			cout<<"  3.Settings"<<endl;
			cout<<endl;
			cout<<"Input 0 to exit"<<endl;
			cout<<"Please input the number:";
			cin>>ans;
			if(ans=="1") help();
			else if(ans=="2") Uptempnew();
			else if(ans=="3") Settings();
			else continue;
		}
		else if(ans=="2")
		{
			cls();
			cout<<"Little Game:"<<endl;
			cout<<"  1.Stone Scissors And Cloth"<<endl;
			cout<<"  2.Hide And Seek"<<endl;
			cout<<"  3.Do Not Press"<<endl;
			cout<<"  4.Guess Number"<<endl;
			cout<<endl;
			cout<<"Input 0 to exit"<<endl;
			cout<<"Please input the number:";
			cin>>ans;
			if(ans=="1") rock();
			else if(ans=="2") find8();
			else if(ans=="3") Surprise();
			else if(ans=="4") Guess();
			else continue;
		}
		else if(ans=="3")
		{
			cls();
			cout<<"Practical tools:"<<endl;
			cout<<"  1.Create Files"<<endl;
			cout<<"  2.Calculator"<<endl;
			cout<<"  3.Mouse linker"<<endl;
			//cout<<"  4.Work Countdown"<<endl;
			cout<<endl;
			cout<<"Input 0 to exit"<<endl;
			cout<<"Please input the number:";
			cin>>ans;
			if(ans=="1") create();
			else if(ans=="2") calculator();
			else if(ans=="3") Mousefp();
			else if(ans=="4") Time();
			else continue;
		}
		else if(ans=="4")
		{
			cls();
			cout<<"Texting tools:"<<endl;
			cout<<"  1.Password Text"<<endl;
			cout<<"  2.Reactivity Test"<<endl;
			cout<<endl;
			cout<<"Input 0 to exit"<<endl;
			cout<<"Please input the number:";
			cin>>ans;
			if(ans=="1") Passwdt();
			else if(ans=="2") fylcs();
			else continue;
		}

		//add here��
		else cls();
	}
}
/*
HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
DWORD mode;
GetConsoleMode(hStdin, &mode);
mode &= ~ENABLE_QUICK_EDIT_MODE;
SetConsoleMode(hStdin, mode);
while(1)
{
	if(KEY_DOWN(VK_LBUTTON))
    {
		POINT p;
		GetCursorPos(&p);
		ScreenToClient(h,&p);
		printf("key down (%d,%d)\n",p.x,p.y);
		mx=p.x;
		my=p.y;
		break;
	}
}
if(my>=88 and my<=109)
{
	ofstream ogi("Temp\\GameImformation.ini");
	ogi<<Gs;
	return 0;
}
*/











