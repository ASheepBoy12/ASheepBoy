#include <windows.h>
#include <bits/stdc++.h>
#include <conio.h>
#include <fstream>
using namespace std;
int Gs;
string GVS="Officialversion:1.4",ans;
void SetWindow(int w,int h,int x,int y)
{
    HWND hwnd = GetForegroundWindow();
    RECT rect;
    GetWindowRect(hwnd, &rect);
    int newWidth = w;
    int newHeight = h;
    SetWindowPos(hwnd,NULL,rect.left,rect.top,newWidth,newHeight,SWP_NOZORDER|SWP_NOMOVE);
    int newX = x;
    int newY = y;
    SetWindowPos(hwnd,NULL,newX,newY,0,0,SWP_NOSIZE|SWP_NOZORDER);
}
void UpDate()
{
	ifstream udt("Temp\\UpDateTemp.ini");
	string update;
	udt>>update;
	udt.close();
	system("mkdir Temp");
	if(update!=GVS)
	{
		udt.close();
		cout<<"Please wait for the update..."<<endl;
		Sleep(500);
		system("cls");
		for(int i=1;i<=3;i++)
		{
			cout<<"Please wait for the update..."<<endl;
			cout<<"Update is loading";
			for(int j=1;j<=3;j++)
			{
				cout<<".";
				Sleep(100);
			}
			system("cls");
		}
		for(int i=1;i<=99;i++)
		{
			system("cls");
			cout<<"Updating..."<<endl;
			if(i%3==0) continue;
			cout<<"Update is finish %"<<i;
		}
		Sleep(200);
		ofstream udt("Temp\\UpDateTemp.ini");
		udt<<GVS;
		udt.close();
		system("cls");
		cout<<"Updating..."<<endl<<"Update is finish %100"<<endl;
		cout<<"Update is complete"<<endl;
		cout<<"Please press any key to continue";
		getch();
	}
	system("cls");
}
string addpd(string upd) 
{
	for(int i=0;i<upd.size();i++)
	{
		upd[i]=upd[i]+'x'+'t'+'h';
		if(i==1) upd[i]+=710;
		if(i==4) upd[i]+=16;
		if(i==16) upd[i]+=2024;
	}
	return upd+upd+upd;
}
void User()
{
	ifstream ut("Temp\\UserImformation.ini");
	if(ut.is_open())
	{
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=20)
			{
				for(int i=10;i>0;i--)
				{
					cout<<"Your computer will shutdown in 10 seconds"<<endl;
					cout<<i;
					Sleep(1000);
					system("cls");
				}
				system("shutdown /s /t 0");
			}
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				system("cls");
			}
			cout<<"Please input "<<tun<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==tup)
			{
				ifstream gi("Temp\\GameImformation.ini");
				if(gi.is_open()) gi>>Gs;
				else Gs=0;
				system("cls");
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				system("cls");
				break;
			}
			else
			{
				system("cls");
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			system("cls");
		}
	}
	else
	{
		ut.close();
		cout<<"This computer does not have user information, please register an account"<<endl;
		string username,upasswd;
		while(1)
		{
			cout<<"Please input the username:";
			cin>>username;
			cout<<endl<<"Please input the password:";
			cin>>upasswd;
			if(upasswd.size()<6)
			{
				cout<<"Please input a longer password"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				system("cls");
				continue;
			}
			if(upasswd==username)
			{
				cout<<"The password can't include the username"<<endl;
				cout<<"Please press any key to continue"<<endl;
				getch();
				system("cls");
				continue;
			}
			break;
		}
		ofstream oui("Temp\\UserImformation.ini");
		oui<<username<<endl<<addpd(upasswd);
		oui.close();
		ofstream outi("Temp\\GameImformation.ini");
		outi<<0;
		outi.close();
		string tun,tup;
		ut>>tun>>tup;
		ut.close();
		cout<<"User data configuration completed, please log in."<<endl;
		cout<<"Please press any key to continue";
		getch();
		oui.close();
		system("cls");
		ifstream ut("Temp\\UserImformation.ini");
		string un,up;
		ut>>un>>up;
		ut.close();
		int times=0;
		while(1)
		{
			if(times>=5)
			{
				cout<<"Please wait for 1 minute and try again";
				Sleep(1000*60);
				system("cls");
			}
			cout<<"Please input "<<un<<"'s password"<<endl;
			string passwd;
			cin>>passwd;
			if(addpd(passwd)==up)
			{
				ifstream gi("Temp\\GameImformation.ini");
				if(gi.is_open()) gi>>Gs;
				else Gs=0;
				system("cls");
				cout<<"Welcome!"<<endl;
				cout<<"Please press any key to continue."<<endl;
				getch();
				system("cls");
				break;
			}
			else
			{
				system("cls");
				cout<<"Wrong password,please input again!"<<endl;
				times++;
				cout<<"Please press any key to continue."<<endl;
				getch();
			}
			system("cls");
		}
	}
}
int Rand(int ranse)
{
	SYSTEMTIME sys;
	GetLocalTime(&sys);
	int Rlocal=sys.wMilliseconds/ranse;
	return Rlocal;
}
void rock()
{
	system("cls");
	while(1)
	{
		cout<<"Please enter gesture number:"<<endl<<"1.Stone 2.Scissors 3.Cloth"<<endl<<"Enter 0 to exit";
		int rock_num,rock_rand=Rand(100);
		if(rock_rand<=2) rock_rand=1;
		else if(rock_rand<=6) rock_rand=2;
		else rock_rand=3;
		cout<<endl;
		cin>>rock_num;
		if(rock_num==0) break;
		else if(rock_num==1)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input STONE!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input SCISSORS!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs CLOTH!"<<endl;Gs+=1;}
		}
		else if(rock_num==2)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input SCISSORS!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input CLOTH!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs STONE!"<<endl;Gs+=1;}
		}
		else if(rock_num==3)
		{
			if(rock_rand==1){cout<<"SCORE DRAW! The robot input CLOTH!"<<endl;Gs+=2;}
			if(rock_rand==2){cout<<"YOU WIN! The robot input STONE!"<<endl;Gs+=3;}
			if(rock_rand==3){cout<<"The robot wins,the robot inputs SCISSORS!"<<endl;Gs+=1;}
		}
		else cout<<"Input error,please re-enter..."<<endl;
		cout<<endl;
	}
	system("cls");
}
void help()
{
	system("cls");
	cout<<"Do you want to download the file:'How To Use This Game.txt'?"<<endl;
	cout<<"1.Yes  2.No"<<endl;
	int helpans;
	cin>>helpans;
	if(helpans==1)
	{
		cout<<"The file is downloading..."<<endl;
		ofstream heof("C:\\Users\\Administrator\\Desktop\\How To Use This Game.txt");
		heof<<"I don't know..."<<endl;
		if(heof.is_open())
		{
			cout<<"Download Accept,please read this file on your desktop"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		heof.close();
	}
	else if(helpans==2)
	{
		cout<<"OK,download is end"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
	}
	else
	{
		cout<<"Input error."<<endl;
		Sleep(1000);
		system("cls");
	}
	system("cls"); 
}
void uptempnew()
{
	system("cls");
	Gs+=2;
	cout<<"Please provide feedback to your email if there are any errors:ASheepBoy@outlook.com"<<endl;
	cout<<"The new of the "<<GVS<<':'<<" (2024.2.5)"<<endl;
	
	cout<<"  -Optimized performance."<<endl;
	cout<<"  -Fixed known errors."<<endl;
	cout<<"  -Add random in Stone Scissors And Cloth."<<endl;
	cout<<"  -Add Guess Number."<<endl;
	cout<<"  -Add random in Hide And Seek."<<endl;
	cout<<"  -Add protective measures."<<endl;
	cout<<"  -Add pleasantly surprised."<<endl;
	cout<<"  -Changed the location of the file"<<endl;
	
	cout<<"If you want to know more about this Game,you can input 1 to download the 'UpDate.txt''"<<endl;
	cout<<"Input 0 to exit"<<endl;
	string uta;
	cin>>uta;
	if(uta=="1")
	{
		cout<<"'UpDate.txt' is download...";
		ofstream utn("C:\\Users\\Administrator\\Desktop\\UpDate.txt");
		utn<<"NEWS(Officialversion:1.1)2024.1.11"<<endl<<"--------------------"<<endl<<"  -Add News."<<endl<<"  -Add the 'NEW' flags."<<endl<<"  -Reset the window."<<endl<<"  -Optimized performance."<<endl<<"  -If you input 20 times wrong password,your PC will shutdown."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.2)2024.1.30"<<endl<<"--------------------"<<endl<<"  -Add Mouse linker."<<endl<<"  -Fixed known errors."<<endl<<"  -Optimized performance."<<endl<<"  -Add error feedback."<<endl<<"  -Optimized the interface."<<endl<<"  -Add the testing website."<<endl<<endl;
		utn<<"NEWS(Officialversion:1.3)2024.2.2"<<endl<<"--------------------"<<endl<<"  -Optimized program code."<<endl<<"  -Revised bonus point rules."<<endl<<"  -Optimized performance."<<endl<<"  -Fixed known errors."<<endl<<"  -Add the date in update imformation."<<endl<<"  -Add the system time."<<endl<<endl;
		if(utn.is_open())
		{
			cout<<"Download Accept,please read this file on your desktop"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=5;
		}
		else
		{
			cout<<"Download Fail,please check your system..."<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=10;
		}
		utn.close();
	}
	else
	{
		system("cls");
	}
	system("cls");
}
void find8()
{
	system("cls");
	cout<<"Please find the '8' in the '0' and enter the position of 8"<<endl;
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
	int randans=Rand(10);
	if(randans<=0||randans>=100) randans=64;
	for(int i=1;i<=100;i++)
	{
		if(i==randans)
		{
			cout<<8;
			continue;
		}
		cout<<0;
	}
	cout<<endl<<"Please input your answer:";
	int fans;
	cin>>fans;
	if(fans==randans)
	{
		cout<<"Congratulations,you answered is correctly.";
		cout<<"The game score will be increased by 10"<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=10;
		system("cls");
	}
	else
	{
		cout<<"Wrong answer..."<<endl;
		cout<<"Please press any key to continue."<<endl;
		getch();
		Gs+=1;
		system("cls");
	}
}
void create()
{
	system("cls");
	cout<<"Are you feeling frustrated about not being able to create files?";
	cout<<" Use this tool to make sure you don't feel frustrated"<<endl;
	string cfname,cfcon;
	cout<<"Please enter the file name:";
	cin>>cfname;
	cout<<endl<<"Please enter the file content:";
	cin>>cfcon;
	cfname="C:\\Users\\Administrator\\Desktop\\"+cfcon+".txt";
	ofstream cfile(cfname.c_str());
	cfile<<cfcon;
	if(cfile.is_open())
	{
		cout<<endl<<"Create success,please read this file on your desktop"<<endl;
		Gs+=5;
	}
	else
	{
		cout<<endl<<"Create fail"<<endl;
		Gs++;
	}
	cfile.close();
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
}
void calculator()
{
	system("cls");
	cout<<"This is a calculator that can help you to count"<<endl;
	cout<<"Only supports addition (+), subtraction (-), multiplication (*), division (/)"<<endl;
	long long n1,n2;
	char fh;
	cin>>n1>>fh>>n2;
	if(fh=='+') cout<<n1<<'+'<<n2<<'='<<n1+n2<<endl;
	else if(fh=='-') cout<<n1<<'-'<<n2<<'='<<n1-n2<<endl;
	else if(fh=='*') cout<<n1<<'*'<<n2<<'='<<n1*n2<<endl;
	else if(fh=='/')cout<<n1<<'/'<<n2<<'='<<n1/n2<<"......"<<n1%n2<<endl;
	else cout<<"Input error..."<<endl;
	Gs+=2;
	cout<<"Please press any key to continue"<<endl;
	getch();
	system("cls");
}
void Mousefp()
{
	system("cls");
    cout<<"Please enter the click interval duration(in ms)(Fastest 1 millisecond):"<<endl;
    int midt;
    cin>>midt;
    system("cls");
	cout<<"Press F2 to execute,press F4 to stop,press ESC to exit"<<endl;
	cout<<"Speed:"<<midt<<"ms/x"<<endl;
	cout<<"(CPS testing website:'5vmc.com/cps')"<<endl;
	Gs+=10; 
	while(1)
	{
		if(GetAsyncKeyState(VK_F2))
		{
			while(1)
			{
				mouse_event(MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_LEFTUP,0,0,0,0);
				if(GetAsyncKeyState(VK_F4))
				{
					break;
				}
				Sleep(midt);
			}
		}
		if(GetAsyncKeyState(VK_ESCAPE))
		{
			break;
		}
	}
	system("cls");
}
void Guess()
{
	system("cls");
	int gans;
	int guenum=Rand(10);
	if(guenum<=0||guenum>=100) guenum=64;
	cout<<"The robot is thinking a number..."<<endl;
	cout<<"The robot is ready,please input a number first(0~100)"<<endl;
	while(1)
	{
		cout<<"Input -1 to exit"<<endl;
		cin>>gans;
		if(gans==guenum)
		{
			cout<<"Congratulations,you answered is correctly.";
			cout<<"The game score will be increased by 100"<<endl;
			cout<<"Please press any key to continue."<<endl;
			getch();
			Gs+=100;
			system("cls");
			break;
		}
		else if(gans==-1) break;
		else
		{
			cout<<"Wrong answer..."<<endl<<endl;
			Gs++;
		}
	}
	system("cls");
}
int main()
{
	SetWindow(900,450,200,200);
	UpDate();
    User();
	system("cls");
	while(1)
	{
		SYSTEMTIME sys;
		GetLocalTime(&sys);
		printf("Now system time:%4d/%02d/%02d %02d:%02d\n",sys.wYear,sys.wMonth,sys.wDay,sys.wHour,sys.wMinute);
		cout<<"NOTE:Please enter 0 to exit the game,";
		cout<<"otherwise the game score will not be saved"<<endl<<endl;
		cout<<"1.Help"<<endl;
		cout<<"2.What's New?"<<endl;
		cout<<"3.Stone Scissors And Cloth"<<endl;
		cout<<"4.Hide And Seek"<<endl;
		cout<<"5.Create Files"<<endl;
		cout<<"6.Calculator"<<endl;
		cout<<"7.Do Not Press"<<endl;
		cout<<"8.Mouse linker"<<endl;
		cout<<"9.Guess Number"<<endl;
		
		//add here��
		cout<<endl;
		cout<<"Your Game score is "<<Gs<<endl;
		cout<<"Please input the Game number(input 0 to exit):";
		cin>>ans;
		if(ans=="0")
		{
			ofstream ogi("Temp\\GameImformation.ini");
			ogi<<Gs;
			return 0;
		}
		else if(ans=="1") help();
		else if(ans=="2") uptempnew();
		else if(ans=="3") rock();
		else if(ans=="4") find8();
		else if(ans=="5") create();
		else if(ans=="6") calculator(); 
		else if(ans=="7") return 0;
		else if(ans=="8") Mousefp();
		else if(ans=="9") Guess();
		//add here�� 
		else system("cls");
	}
}














